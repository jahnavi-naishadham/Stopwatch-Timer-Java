/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stopwatch;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class OptionsScreen extends JPanel implements ActionListener {

    ModernButton timerBtn = new ModernButton("TIMER");
    ModernButton stopwatchBtn = new ModernButton("STOPWATCH");

    public OptionsScreen() {

        setLayout(null);
        setBounds(0, 0, 500, 500);
        setBackground(ModernTheme.BG);

        JLabel title = new JLabel("TIME UTILITY");
        title.setFont(ModernTheme.TITLE_FONT);
        title.setForeground(ModernTheme.TEXT_DARK);
        title.setBounds(120, 40, 400, 40);

        stopwatchBtn.setBounds(150, 150, 200, 55);
        stopwatchBtn.addActionListener(this);

        timerBtn.setBounds(150, 240, 200, 55);
        timerBtn.addActionListener(this);

        add(title);
        add(stopwatchBtn);
        add(timerBtn);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == timerBtn) {
            WindowManager.showTimer();
        } else if (e.getSource() == stopwatchBtn) {
            WindowManager.showStopwatch();
        }
    }
}
