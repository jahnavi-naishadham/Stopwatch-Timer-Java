/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stopwatch;

import javax.swing.*;

public class WindowManager {

    private static JFrame frame;

    public static void init() {
        frame = new JFrame("Time Utility");
        frame.setSize(500, 500);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        showOptions();
        frame.setVisible(true);
    }

    public static void showOptions() {
        frame.getContentPane().removeAll();
        frame.add(new OptionsScreen());
        frame.repaint();
        frame.revalidate();
    }

    public static void showStopwatch() {
        frame.getContentPane().removeAll();
        frame.add(new StopwatchScreen());
        frame.repaint();
        frame.revalidate();
    }

    public static void showTimer() {
        frame.getContentPane().removeAll();
        frame.add(new CountTimerScreen());
        frame.repaint();
        frame.revalidate();
    }
}
