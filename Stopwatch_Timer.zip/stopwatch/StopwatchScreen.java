/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stopwatch;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StopwatchScreen extends JPanel implements ActionListener {

    ModernButton startBtn = new ModernButton("START");
    ModernButton resetBtn = new ModernButton("RESET");
    ModernButton optionsBtn = new ModernButton("OPTIONS");
    JLabel timeLabel = new JLabel();

    int elapsedTime = 0;
    int seconds = 0, minutes = 0, hours = 0;
    boolean started = false;

    Timer timer = new Timer(1000, e -> updateTime());

    public StopwatchScreen() {

        setLayout(null);
        setBounds(0, 0, 500, 500);
        setBackground(ModernTheme.BG);

        timeLabel.setText("00:00:00");
        timeLabel.setBounds(110, 80, 280, 100);
        timeLabel.setFont(ModernTheme.TIME_FONT);
        timeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        timeLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        startBtn.setBounds(60, 250, 120, 50);
        startBtn.addActionListener(this);

        resetBtn.setBounds(190, 250, 120, 50);
        resetBtn.addActionListener(this);

        optionsBtn.setBounds(320, 250, 120, 50);
        optionsBtn.addActionListener(this);

        add(timeLabel);
        add(startBtn);
        add(resetBtn);
        add(optionsBtn);
    }

    private void updateTime() {
        elapsedTime += 1000;
        hours = elapsedTime / 3600000;
        minutes = (elapsedTime / 60000) % 60;
        seconds = (elapsedTime / 1000) % 60;

        timeLabel.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds));
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == startBtn) {
            if (!started) {
                started = true;
                startBtn.setText("STOP");
                timer.start();
            } else {
                started = false;
                startBtn.setText("START");
                timer.stop();
            }
        }

        if (e.getSource() == resetBtn) {
            timer.stop();
            started = false;
            startBtn.setText("START");
            elapsedTime = 0;
            timeLabel.setText("00:00:00");
        }

        if (e.getSource() == optionsBtn) {
            timer.stop();
            WindowManager.showOptions();
        }
    }
}
