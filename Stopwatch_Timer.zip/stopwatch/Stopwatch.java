/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stopwatch;
import javax.swing.*;
/**
 *
 * @author janu28
 */
public class Stopwatch {

    public static void main(String[] args) {
        WindowManager.init();
    }
}
