/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stopwatch;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CountTimerScreen extends JPanel implements ActionListener {

    ModernButton startBtn = new ModernButton("START");
    ModernButton resetBtn = new ModernButton("RESET");
    ModernButton optionsBtn = new ModernButton("OPTIONS");
    JLabel timeLabel = new JLabel();

    int hours, minutes, seconds;
    boolean started = false;

    Timer timer = new Timer(1000, e -> updateTime());

    public CountTimerScreen() {

        // ASK USER FOR TIME VALUES
        getUserInput();

        setLayout(null);
        setBounds(0, 0, 500, 500);
        setBackground(ModernTheme.BG);

        timeLabel.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds));
        timeLabel.setBounds(110, 80, 280, 100);
        timeLabel.setFont(ModernTheme.TIME_FONT);
        timeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        timeLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        startBtn.setBounds(60, 250, 120, 50);
        startBtn.addActionListener(this);

        resetBtn.setBounds(190, 250, 120, 50);
        resetBtn.addActionListener(this);

        optionsBtn.setBounds(320, 250, 120, 50);
        optionsBtn.addActionListener(this);

        add(timeLabel);
        add(startBtn);
        add(resetBtn);
        add(optionsBtn);
    }

    private void getUserInput() {
        JTextField h = new JTextField("0");
        JTextField m = new JTextField("0");
        JTextField s = new JTextField("0");

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.add(new JLabel("Hours:"));
        panel.add(h);
        panel.add(new JLabel("Minutes:"));
        panel.add(m);
        panel.add(new JLabel("Seconds:"));
        panel.add(s);

        int result = JOptionPane.showConfirmDialog(
                null,
                panel,
                "Set Timer Duration",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            try {
                hours = Integer.parseInt(h.getText());
                minutes = Integer.parseInt(m.getText());
                seconds = Integer.parseInt(s.getText());
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Invalid input! Setting timer to 00:01:00");
                hours = 0;
                minutes = 1;
                seconds = 0;
            }
        } else {
            // If user presses CANCEL → go back to options screen
            WindowManager.showOptions();
        }
    }

    private void updateTime() {

        seconds--;

        if (seconds < 0) { seconds = 59; minutes--; }
        if (minutes < 0) { minutes = 59; hours--; }

        timeLabel.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds));

        if (hours == 0 && minutes == 0 && seconds == 0) {
            timer.stop();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == startBtn) {
            if (!started) {
                started = true;
                startBtn.setText("STOP");
                timer.start();
            } else {
                started = false;
                startBtn.setText("START");
                timer.stop();
            }
        }

        if (e.getSource() == resetBtn) {
            timer.stop();
            started = false;
            startBtn.setText("START");
            getUserInput(); // ask again
            timeLabel.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds));
        }

        if (e.getSource() == optionsBtn) {
            timer.stop();
            WindowManager.showOptions();
        }
    }
}
