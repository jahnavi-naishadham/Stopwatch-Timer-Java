/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stopwatch;

import java.awt.*;

public class ModernTheme {

    public static final Color PRIMARY = new Color(52, 152, 219);
    public static final Color PRIMARY_DARK = new Color(41, 128, 185);
    public static final Color BG = new Color(245, 245, 245);
    public static final Color TEXT_DARK = new Color(30, 30, 30);

    public static Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 30);
    public static Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 18);
    public static Font TIME_FONT = new Font("Consolas", Font.BOLD, 40);
}
